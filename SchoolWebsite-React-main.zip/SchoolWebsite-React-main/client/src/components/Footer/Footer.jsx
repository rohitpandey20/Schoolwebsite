import React from 'react'
import './Footer.css';

function Footer() {
    return (
        <p className='footer-text'>Copyright &copy; 2020 Learning Curve Public School</p>
    )
}

export default Footer
