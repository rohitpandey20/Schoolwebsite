import React from 'react'

function Header() {
    return (
        <h1 style={{textAlign: 'center'}}>Learning Curve Public School</h1>
    )
}

export default Header
